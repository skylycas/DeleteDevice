﻿using DeleteDevice.Models;
using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Management.Automation;
namespace DeleteDevice.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=LcboDevices;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        public IActionResult Index()
        {
            if(!string.IsNullOrEmpty(HttpContext.Session.GetString("ssErrMsg")))
            {
                ViewBag.retVal = HttpContext.Session.GetString("ssErrMsg");
                HttpContext.Session.Remove("ssErrMsg");
            }
            return View();
        }

        [HttpPost]
        public IActionResult Index(UsersModel usersModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    SqlConnection connection = new SqlConnection(connectionString);

                    string selectQuery = "Select * from tblUsers Where Emailaddress = '" + usersModel.mdEmail + "' AND Password='" + usersModel.mdPassword + "'";
                    SqlCommand sqlCommand = new SqlCommand(selectQuery, connection);
                    connection.Open();
                    SqlDataReader reader = sqlCommand.ExecuteReader();
                    if (reader.Read())
                    {
                        HttpContext.Session.SetString("ssFirstName", reader.GetString(2));
                        HttpContext.Session.SetString("ssLastname", reader.GetString(3));
                        HttpContext.Session.SetString("ssEmail", usersModel.mdEmail);

                        connection.Close();          

                        return RedirectToAction("Landing");
                    }
                    else
                    {
                        ViewBag.retVal = "Invalid email or password!!!";
                    }

                }
                catch (Exception ex)
                {
                    ViewBag.retVal = ex.Message;
                }
            }
            return View();
        }

        public IActionResult Signup()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Signup(UsersModel usersModel)
        {
            if(ModelState.IsValid)
            {
                try
                {
                    SqlConnection connection = new SqlConnection(connectionString);

                    string selectQuery = "Select * from tblUsers Where Emailaddress = '" + usersModel.mdEmail + "'";
                    SqlCommand checkCommand = new SqlCommand(selectQuery, connection);
                    connection.Open();
                    SqlDataReader reader = checkCommand.ExecuteReader();
                    if (reader.Read())
                    {
                        connection.Close();
                        ViewBag.retVal = "Email already exists";
                    }
                    else
                    {
                        connection.Close();
                        string insertQuery = "INSERT INTO tblUsers(Emailaddress, FirstName, LastName, Password) VALUES('" + usersModel.mdEmail + "', '" + usersModel.mdFirstName + "', '" + usersModel.mdLastName + "', '" + usersModel.mdPassword + "')";
                        SqlCommand command = new SqlCommand(insertQuery, connection);
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();

                        HttpContext.Session.SetString("ssFirstName", usersModel.mdFirstName);
                        HttpContext.Session.SetString("ssLastname", usersModel.mdLastName);
                        HttpContext.Session.SetString("ssEmail", usersModel.mdEmail);

                        HttpContext.Session.SetString("ssMessage", "Hi " + usersModel.mdFirstName + ", you have been registered!");
                        return RedirectToAction(actionName: "Congrats");
                    }
                }
                catch(Exception ex)
                {
                    ViewBag.retVal = ex.Message;
                }
            }
            return View();
        }

        public IActionResult Forgotpassword()
        {
            return View();
        }
        public IActionResult Congrats()
        {
            ViewBag.retVal = HttpContext.Session.GetString("ssMessage");
            HttpContext.Session.Remove("ssMessage");
            return View();
        }

        [HttpGet]
        public IActionResult Landing()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("ssEmail")))
            {
                HttpContext.Session.SetString("ssErrMsg", "You must login first");
                return RedirectToAction(actionName: "Index");
            }
            else
            {
                List<DeviceModel> deviceslist = new List<DeviceModel>();
                string? uesrEmail = HttpContext.Session.GetString("ssEmail");
                try
                {
                    SqlConnection connection = new SqlConnection(connectionString);

                    string selectQuery = "Select Computername,Status,Addedby,CONVERT(VARCHAR(30),Datecreated,0) AS Datecreated,ISNULL(CONVERT(VARCHAR(30),Dateupdated,0), 'N/A') AS Dateupdated FROM tblDevices Where Addedby = '" + uesrEmail + "' order by DateCreated Desc";
                    SqlCommand sqlCommand = new SqlCommand(selectQuery, connection);
                    connection.Open();
                    SqlDataReader reader = sqlCommand.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            DeviceModel deviceModel = new DeviceModel();
                            deviceModel.mdComputerName = reader.GetString("Computername");
                            deviceModel.mdStatus = reader.GetString("Status");
                            deviceModel.mdAddedby = reader.GetString("Addedby");
                            deviceModel.mdDatecreated = reader.GetString("Datecreated");
                            deviceModel.mdDateupdated = reader.GetString("Dateupdated");
                            deviceslist.Add(deviceModel);
                        }
                        connection.Close();

                        ViewBag.devices = deviceslist;
                    }
                    else
                    {
                        ViewBag.retVal = "No record found!";
                    }

                }
                catch (Exception ex)
                {
                    ViewBag.retVal = ex.Message;
                }
                createName();
                return View();
            }
        }

        [HttpGet]
        public IActionResult AddDevice()
        {
         if(string.IsNullOrEmpty(HttpContext.Session.GetString("ssEmail")))
            {
                HttpContext.Session.SetString("ssErrMsg", "You must login first before you can add a device");
                return RedirectToAction(actionName: "Index");
            }
            else
            {
                createName();
                return View();
            }
        }

        [HttpPost]
        public IActionResult AddDevice(DeviceModel deviceModel)
        {
            try
            {
                if (string.IsNullOrEmpty(HttpContext.Session.GetString("ssEmail")))
                {
                    HttpContext.Session.SetString("ssErrMsg", "Session expired");
                    return RedirectToAction(actionName: "Index");
                }

                if (ModelState.IsValid)
                {
                    string? email = HttpContext.Session.GetString("ssEmail");

                    SqlConnection connection = new SqlConnection(connectionString);

                    string selectQuery = "Select * from tblDevices Where Computername = '" + deviceModel.mdComputerName + "'";
                    SqlCommand checkCommand = new SqlCommand(selectQuery, connection);
                    connection.Open();
                    SqlDataReader reader = checkCommand.ExecuteReader();
                    if (reader.Read())
                    {
                        connection.Close();
                        ViewBag.retVal = "Computer Name " + deviceModel.mdComputerName + " already exists!";
                    }
                    else
                    {
                        connection.Close();
                        string insertQuery = "INSERT INTO tblDevices(Computername, Addedby) VALUES('" + deviceModel.mdComputerName + "', '" + email + "')";
                        SqlCommand command = new SqlCommand(insertQuery, connection);
                        connection.Open();
                        command.ExecuteNonQuery();
                        connection.Close();

                        ViewBag.retVal = deviceModel.mdComputerName + " added successfully!";
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.retVal = ex.Message;
            }
            createName();
            return View();
        }



        [HttpGet]
        public IActionResult DeleteNow()
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("ssEmail")))
            {
                HttpContext.Session.SetString("ssErrMsg", "You must login first before you can delete a device");
                return RedirectToAction(actionName: "Index");
            }
            else
            {
                createName();
                return View();
            }
        }

        [HttpPost]
        public IActionResult DeleteNow(DeviceModel deviceModel)
        {
            try
            {
                if (string.IsNullOrEmpty(HttpContext.Session.GetString("ssEmail")))
                {
                    HttpContext.Session.SetString("ssErrMsg", "Session expired");
                    return RedirectToAction(actionName: "Index");
                }

                if (ModelState.IsValid)
                {
                    string? email = HttpContext.Session.GetString("ssEmail");

                    

                    using (PowerShell ps = PowerShell.Create())
                    {

                        //PowerShell ps = PowerShell.Create();

                        string inputtype = "text";
                        string? ComputerName = deviceModel.mdComputerName;
                        string scriptPath = @"C:\Users\YUDO\source\repos\DeleteDevice\DeleteDevice\wwwroot\assets\DeleteDevice\DeleteDevice.ps1";
                        ps.AddScript(System.IO.File.ReadAllText(scriptPath));

                        ps.AddArgument(inputtype);
                        ps.AddArgument(ComputerName);

                        ps.Invoke();
                    }

                    SqlConnection connection = new SqlConnection(connectionString);

                    string updateQuery = "Update tblDevices SET Status='Done', Dateupdated = GETDATE() Where Computername = '" + deviceModel.mdComputerName + "'";
                    SqlCommand command = new SqlCommand(updateQuery, connection);
                    connection.Open();
                    command.ExecuteNonQuery();
                    connection.Close();
                    ViewBag.retVal = deviceModel.mdComputerName + " deleted successfully!";
                }
            }
            catch (Exception ex)
            {
                ViewBag.retVal = ex.Message;
            }
            createName();
            return View();
        }

        public void createName()
        {
            ViewBag.name = HttpContext.Session.GetString("ssFirstName") + ", " + HttpContext.Session.GetString("ssLastname");
        }






        [HttpGet]
        public IActionResult Logout()
        {
            //this is called when the anchor tag logout is clicked
            HttpContext.Session.Remove("ssFirstName");
            HttpContext.Session.Remove("ssLastname");
            HttpContext.Session.Remove("ssEmail");
            return RedirectToAction(actionName: "Index");
            //return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}