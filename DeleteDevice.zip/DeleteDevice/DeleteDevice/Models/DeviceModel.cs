﻿namespace DeleteDevice.Models
{
    public class DeviceModel
    {
        public string? mdComputerName { get; set; }
        public string? mdStatus { get; set; } = string.Empty;
        public string? mdAddedby { get; set; } = string.Empty;
        public string? mdDatecreated { get; set; } = string.Empty;
        public string? mdDateupdated { get; set; } = string.Empty;
    }
}
