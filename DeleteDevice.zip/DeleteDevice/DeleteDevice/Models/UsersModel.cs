﻿namespace DeleteDevice.Models
{
    public class UsersModel
    {
        public string? mdEmail { get; set; } = string.Empty;
        public string? mdFirstName { get; set; } = string.Empty;
        public string? mdLastName { get; set; } = string.Empty;
        public string? mdPassword { get; set; } = string.Empty;
    }
}
