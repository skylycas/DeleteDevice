﻿Param ([Parameter(Mandatory)][ValidateSet("text", "file")]$inputtype,
[string[]] $ComputerNames,
$filepath='./hostnames.txt',
$sccmServer='euc001.lcbo.com')

$serialNums = New-Object System.Collections.ArrayList

try
{
    Write-host "Importing modules..."
    if(!(Get-InstalledModule -Name "Microsoft.Graph.Intune"))
    {
        Import-Module Microsoft.Graph.Intune -ErrorAction Stop
        Write-Host "Microsoft Graph Intune Imported!" -ForegroundColor Green
    }
    
    if(!(Get-InstalledModule -Name "AzureAD"))
    {
        Import-Module AzureAD -ErrorAction Stop
        Write-Host "Azure AD imported!" -ForegroundColor Green
    }
    
    
    Connect-AzureAD
    Write-Host "connected to AZURE AD successfully" -ForegroundColor Green
    Connect-MSGraph
    Write-Host "connected to INTUNE successfully" -ForegroundColor Green



    #if inpute type is file, then a file path must be specified
    if($inputtype -eq "file")
    {
        if($filepath -eq $null -or $filepath -eq "")
        {
            Write-Host "You must specify -filepath if Inputtype is set to file is selected" -ForegroundColor Red
            [System.Windows.MessageBox]::Show('You must specify -filepath if Inputtype is set to file is selected')
            break
        }
        else
        {
            $ComputerNames = Get-Content -Path $filepath
        }
    }
}
Catch
{
    Get-Date| Out-file -Append ".\logs.txt"
    '----------------------------------------------'| Out-file -Append ".\logs.txt"
    $_ | Out-file -Append ".\logs.txt"
    break
}


#-----------SELP Function
Function Sleep-Progress($seconds, $valString) {
    $s = 0
    Do {
        $p = [math]::Round(100 - (($seconds - $s) / $seconds * 100))
        Write-Progress -Activity "$valString" -Status "$p% Complete:" -SecondsRemaining ($seconds - $s) -PercentComplete $p
        [System.Threading.Thread]::Sleep(500)
        $s++;
    }
    While($s -lt $seconds);
}


foreach($ComputerName in $ComputerNames)
{
    
    Write-Host "`r`n-------------------------------------------------------------Active directory Delete Started" -ForegroundColor DarkYellow
    Try
    {    
        Write-host "Searching " -NoNewline
        Write-host "Active Directory " -ForegroundColor Yellow -NoNewline
        Write-host "for $ComputerName ...`r"   
        $Searcher = [ADSISearcher]::new()
        $Searcher.Filter = "(sAMAccountName=$ComputerName`$)"
        [void]$Searcher.PropertiesToLoad.Add("distinguishedName")
        $ComputerAccount = $Searcher.FindOne()
        If ($ComputerAccount)
        {
            Write-host "$ComputerName found Successfully `r" -ForegroundColor Green
            Write-Host "   Deleting computer $ComputerName ...`r"
            $DirectoryEntry = $ComputerAccount.GetDirectoryEntry()

            #---Delete action happens here
            $Result = $DirectoryEntry.DeleteTree()

            Write-Host "$ComputerName deleted from Active Directory Successfully!" -ForegroundColor Green
            #Write-Host $DirectoryEntry.name
            #Write-Host $ComputerAccount.Path
        }
        Else
        {
            Write-host "$ComputerName Not found in AD!" -ForegroundColor Red
        }
    }
    Catch
    {
        Write-host "An error occurred at Active Directory level, check log file for details!" -ForegroundColor Red

        Get-Date| Out-file -Append ".\logs.txt"
        '----------------------------------------------'| Out-file -Append ".\logs.txt"
        $_ | Out-file -Append ".\logs.txt"
        break
    }
    Write-Host "`r`n------------------------------------------------------------Active directory Delete Ended" -ForegroundColor DarkYellow


    Write-Host "`r`n------------------------------------------------------------SCCM Delete Started" -ForegroundColor DarkYellow
    Try
    {
        Import-Module $env:SMS_ADMIN_UI_PATH.Replace('i386','ConfigurationManager.psd1') -ErrorAction Stop
        #$sccmSite = "LCB"
        Write-host "Searching " -NoNewline
        Write-host "SCCM " -ForegroundColor Yellow -NoNewline
        Write-host "device record/s for $ComputerName ...`r"
        $sccmSite = (Get-PSDrive -PSProvider CMSITE -ErrorAction Stop).Name
        Write-Host "Success `r" -ForegroundColor Green
        # find and delete from SCCM
        $comp = get-wmiobject -query "select * from SMS_R_SYSTEM WHERE Name='$computerName'" -computername $sccmServer -namespace "ROOT\SMS\site_$sccmSite"
        Write-host "   Deleting Name: $($comp.Name)  |  ResourceID: $($comp.ResourceID)...`r"

        if($comp)
        {
             #---Delete action happens here
            $comp.psbase.delete()
            Write-Host "$ComputerName deleted from SCCM Successfully!" -ForegroundColor Green
        }
        else
        {
             Write-host "$ComputerName Not found in SCCM!" -ForegroundColor Red
        }
        #Write-Host $comp.ResourceNames
        #Write-Host $comp.SID

        #Write-Host $SiteCode

    }
    Catch
    {
        Write-host "An error occurred at SCCM level, check log file for details!" -ForegroundColor Red

        Get-Date| Out-file -Append ".\logs.txt"
        '----------------------------------------------'| Out-file -Append ".\logs.txt"
        $_ | Out-file -Append ".\logs.txt"
        break
    }

    Write-Host "`r`n-----------------------------------------------------------------SCCM Delete Ended" -ForegroundColor DarkYellow



    Write-Host "`r`n------------------------------------------------------------Intune Device Delete Started" -ForegroundColor DarkYellow

     Try
    {
        #Connect-MSGraph
        Write-host "Searching " -NoNewline
        Write-host "Intune " -ForegroundColor Yellow -NoNewline
        Write-host "managed device record/s for $ComputerName ....`r"
        [array]$IntuneDevices = Get-IntuneManagedDevice -Filter "deviceName eq '$ComputerName'" -ErrorAction Stop
        If ($IntuneDevices.Count -ge 1)
        {
            Write-Host "$ComputerName found successfully! `r" -ForegroundColor Green
            foreach ($IntuneDevice in $IntuneDevices)
            {
                Write-host "   Deleting DeviceName: $($IntuneDevice.deviceName)  | SerialNumber: $($IntuneDevice.serialNumber) ...`r"

                #add serial number
                $serialNums.Add($IntuneDevice.serialNumber)

                #---Delete action happens here
                Remove-IntuneManagedDevice -managedDeviceId $IntuneDevice.Id -Verbose -ErrorAction Stop

                #wait for the delete t complete
                Sleep-Progress 180 "Deleting $ComputerName from Intune Devices..."

                Write-host "$ComputerName deleted Successfully!!`r" -ForegroundColor Green

                # Write-Host $IntuneDevice
            }
            #Write-Host $IntuneDevices
        }
        Else
        {
            Write-host "$ComputerName Not found in Intune Devices !" -ForegroundColor Red
        }
    }
    Catch
    {
        Write-host "An error occurred at Intune Devices level, check log file for details!" -ForegroundColor Red

        Get-Date| Out-file -Append ".\logs.txt"
        '----------------------------------------------'| Out-file -Append ".\logs.txt"
        $_ | Out-file -Append ".\logs.txt"
        break
    }

    Write-Host "`r`n------------------------------------------------------------Intune Device Delete Ended" -ForegroundColor DarkYellow



    Write-Host "`r`n------------------------------------------------------------Enrollment Device Delete Started" -ForegroundColor DarkYellow
    Try
    {
        #Connect-MSGraph
        Write-host "Searching " -NoNewline
        Write-host "Intune " -ForegroundColor Yellow -NoNewline
        Write-host "managed device record/s for $ComputerName ....`r"
        #[array]$IntuneDevices = Get-IntuneManagedDevice -Filter "deviceName eq '$ComputerName'" -ErrorAction Stop
        Write-host "Retrieving " -NoNewline
        Write-host "Autopilot " -ForegroundColor Yellow -NoNewline
        Write-host "device registration for $ComputerName ....`r" 
        $AutopilotDevices = New-Object System.Collections.ArrayList
        if($serialNums.Count -ge 1)
        {
            foreach ($serialNumber in $serialNums)
            {
                $URI = "https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities?`$filter=contains(serialNumber,'$($serialNumber)')"
                $AutopilotDevice = Invoke-MSGraphRequest -Url $uri -HttpMethod GET -ErrorAction Stop
                [void]$AutopilotDevices.Add($AutopilotDevice)
            }
            Write-Host "Success" -ForegroundColor Green

            foreach ($device in $AutopilotDevices)
            {
                Write-host "   Deleting SerialNumber: $($Device.value.serialNumber)  |  Model: $($Device.value.model)  |  Id: $($Device.value.id)  |  GroupTag: $($Device.value.groupTag)  |  ManagedDeviceId: $($device.value.managedDeviceId) ..." -NoNewline
                $URI = "https://graph.microsoft.com/beta/deviceManagement/windowsAutopilotDeviceIdentities/$($device.value.Id)"

                #---Delete action happens here
                $AutopilotDevice = Invoke-MSGraphRequest -Url $uri -HttpMethod DELETE -ErrorAction Stop
                    #wait for the delete to complete
                Sleep-Progress 180 "Deleting $ComputerName from enrollment..."

                Write-host $ComputerName "deleted Successfully!!`r" -ForegroundColor Green

                #Write-Host $URI "--------------------"
                #Write-Host $uri "--------------------"
            }
        }
        Else
        {
            Write-host "$ComputerName Not found in Enrollment!" -ForegroundColor Red
        }

    }
    Catch
    {
        Write-host "An error occurred at Delete Enrollement level, check log file for details!" -ForegroundColor Red

        Get-Date| Out-file -Append ".\logs.txt"
        '----------------------------------------------'| Out-file -Append ".\logs.txt"
        $_ | Out-file -Append ".\logs.txt"
        break
    }
    Write-Host "`r`n------------------------------------------------------------Enrollment Device Delete Ended" -ForegroundColor DarkYellow


    Write-Host "`r`n------------------------------------------------------------Azure AD Delete Started" -ForegroundColor DarkYellow

    Try
    {
        #Connect-AzureAD
        Write-host "Searhcing " -NoNewline
        Write-host "Azure AD " -ForegroundColor Yellow -NoNewline
        Write-host "device record/s for $ComputerName ...`r"
        [array]$AzureADDevices = Get-AzureADDevice -SearchString $ComputerName -All:$true -ErrorAction Stop
        If ($AzureADDevices.Count -ge 1)
        {
            Write-Host "$ComputerName found Successfully!! `r" -ForegroundColor Green
            Foreach ($AzureADDevice in $AzureADDevices)
            {
                Write-host "   Deleting DisplayName: $($AzureADDevice.DisplayName)  |  ObjectId: $($AzureADDevice.ObjectId)  |  DeviceId: $($AzureADDevice.DeviceId) ...`r"

                #---Delete action happens here
                Remove-AzureADDevice -ObjectId $AzureADDevice.ObjectId -ErrorAction Stop
                Sleep-Progress 60 "Deleting $ComputerName from Azure AD..."

                Write-host "$ComputerName deleted Successfully!!`r" -ForegroundColor Green
            }
        }
        Else
        {
            Write-host "$ComputerName Not found!" -ForegroundColor Red
        }
    }
    Catch
    {
        Write-host "An error occurred at Azure Active Directory level, check log file for details!" -ForegroundColor Red

        Get-Date| Out-file -Append ".\logs.txt"
        '----------------------------------------------'| Out-file -Append ".\logs.txt"
        $_ | Out-file -Append ".\logs.txt"
        break
    }



}

Write-Host "All process completed!!" -ForegroundColor Green